# JoJoLife — protótipo 0.7.2

Jogo de simulação de vida inspirado em JoJo's Bizarre Adventure. Projeto de fã, não oficial.

## Novidades da versão 0.7

- Cinco novos Stands no catálogo: Killer Queen, Echoes ACT 1, Scary Monsters, Tusk ACT 1 e Green Day.
- Evoluções implementadas: Echoes ACT 1 → ACT 2 → ACT 3; Tusk ACT 1 → ACT 2 → ACT 3 → ACT 4; Killer Queen → Killer Queen: Bites the Dust; Scary Monsters → forma completa.
- Treino de Stand aumenta domínio. Tusk também pode evoluir por contato com partes do Cadáver Santo; ACT 4 exige domínio do Spin.
- Busca rara pela Flecha Requiem e evolução Requiem quando o Stand tem domínio suficiente.
- Faculdade e cursos profissionalizantes, com graduações e profissões especializadas que exigem diploma.
- Caminho opcional de vilão, criação de organização, recrutamento de subordinados e confrontos com grupos de protagonistas.
- Grupos de protagonistas originais na linha do tempo original e personagens da continuidade escolhida nas Partes canônicas.
- Encontros sobrenaturais por época: vampiros e criaturas da Máscara de Pedra nas Partes 1 e 2; usuários de Stand nas Partes 3 a 9. A linha do tempo original pode apresentar ambos.
- O jogo mantém oito ações por ano.
- Salvamentos da versão 0.6 continuam carregáveis; a versão 0.7 grava em uma nova chave e atualiza dados ausentes.

## Como jogar

Abra `index.html` em um navegador moderno. O progresso é salvo no armazenamento local do navegador. Use os botões de Salvar e Carregar para gerenciar a vida.

## Observações

- As graduações avançam no máximo um ano acadêmico por idade/ano do personagem.
- A Flecha Requiem é rara; a busca pode falhar e causar ferimentos.
- Encontros de campanha podem iniciar combates automaticamente após avançar o ano. Em combate, não é possível avançar o tempo.
- A morte encerra a vida atual.

## Correção 0.7.1 — Steel Ball Run

- A inscrição inicia uma campanha independente de nove etapas.
- Cada etapa apresenta uma cena e três estratégias com consequências para pontuação e saúde.
- A idade e as ações anuais ficam congeladas durante toda a corrida; o botão de avançar ano fica bloqueado.
- Ao concluir a nona etapa, a colocação e o prêmio são calculados pelo desempenho. O primeiro lugar paga ¥50.000.000.
- O progresso da corrida é salvo junto com a vida e pode ser retomado após carregar o jogo.
- Ao concluir a corrida, o calendário normal é retomado sem envelhecer o personagem durante as etapas.


## Atualização 0.7.2 — ataques de Stand e cura

- Cada um dos 17 Stands do catálogo tem quatro técnicas de combate próprias, exibidas como opções separadas durante as lutas. Stands personalizados e manifestações criadas pela personalidade recebem quatro técnicas genéricas adaptadas ao nome e à descrição.
- Cada Stand também tem um quinto ataque especial. A barra carrega 25% por golpe de Stand acertado; ao chegar a 100%, o especial pode ser usado.
- Os especiais são temáticos e têm efeitos distintos: parada do tempo para Star Platinum e The World; restauração de saúde para Crazy Diamond; Bites the Dust para Killer Queen após sua evolução; 3 Freeze para Echoes ACT 3; Rotação Infinita para Tusk ACT 4; mofo contínuo para Green Day, entre outros.
- Killer Queen antes de Bites the Dust, Echoes antes do ACT 3 e Tusk antes do ACT 4 usam especiais adequados à sua forma atual; as técnicas finais respeitam os requisitos de evolução.
- A loja oferece bandagem individual (¥35) e pacote com três (¥90). Cada bandagem recupera até 28 pontos de saúde, pode ser usada durante um combate (consumindo o turno e permitindo a resposta do inimigo) ou fora dele (consumindo uma ação anual).
- A saúde continua limitada a 100; bandagens não podem ultrapassar esse limite. A possibilidade de morrer em combate permanece ativa.
- Os dados de bandagens são adicionados automaticamente aos salvamentos anteriores.
- A Steel Ball Run da versão 0.7.1 foi preservada: nove etapas independentes, sem avanço de idade e sem consumo das ações anuais.

## Verificações realizadas na 0.7.2

- Sintaxe JavaScript validada com Node.js.
- Testes automatizados confirmaram quatro ataques e um especial na interface para cada um dos 17 Stands.
- Testes confirmaram carga do especial após quatro golpes, restauração de saúde do Bites the Dust evoluído e consumo de bandagem em combate.
- Testes confirmaram que os especiais de Killer Queen, Echoes e Tusk respeitam as evoluções correspondentes.
- Teste de regressão confirmou que a Steel Ball Run avança etapas sem avançar a idade nem consumir ações anuais.
- Não foi realizado teste completo em navegador gráfico.


## Atualização 0.8.0 — Relíquias, Requiem e laços entre personagens

- Cadáver Santo: ao recuperar a primeira parte na Steel Ball Run, um personagem sem Stand desperta automaticamente uma manifestação aleatória.
- Máscara de Pedra: deixa de conceder Stands; sua utilização transforma o personagem em vampiro.
- Flecha Requiem: exige domínio 25 no Stand. A tentativa pode ser fatal; quem sobrevive ainda precisa ser considerado digno para desbloquear uma sexta habilidade individualizada.
- Sexta habilidade Requiem: habilidade adicional utilizável em combate, com efeitos temáticos de acordo com o Stand.
- Relações: nova área para conhecer personagens da Parte escolhida, construir amizades, formar alianças, namorar e casar.
- Encontros aleatórios: protagonistas, aliados, rivais e vilões podem surgir durante a progressão anual; encontros com vilões permitem conversar, propor aliança ou lutar.
- Compatibilidade: novos campos são inicializados automaticamente em salvamentos antigos.

### Observação de balanceamento
Os encontros com personagens são probabilísticos. A relação é representada por 0–100; alianças exigem 35 pontos (25 em encontros diretos com vilões), namoro exige 55 e casamento exige 80, maioridade e relacionamento ativo.
