# JoJoLife 0.8.0 — Android

Projeto Android WebView baseado no invólucro Android preparado para JoJoLife 0.7.2, atualizado com o jogo JoJoLife 0.8.0.

## Compilação

Requer JDK 17 e Gradle 8.9. Execute na pasta `JoJoLife072`:

```bash
gradle --no-daemon assembleDebug
```

APK de depuração: `app/build/outputs/apk/debug/app-debug.apk`.
