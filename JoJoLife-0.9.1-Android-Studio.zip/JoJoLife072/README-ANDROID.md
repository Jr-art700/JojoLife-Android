# JoJoLife 0.9.0 — Android

Projeto Android do JoJoLife 0.9.0. O jogo é executado localmente em uma WebView.

## Compilar
Abra esta pasta no Android Studio ou use Gradle 8.9 e Java 17:
`gradle --no-daemon assembleDebug`

APK de depuração: `app/build/outputs/apk/debug/app-debug.apk`.

Esta versão adiciona raças, organizações, missões, cassinos, operações criminais fictícias, vampirismo, Catch the Rainbow, Silver Chariot e correções de progressão Requiem. Teste o APK no aparelho antes de distribuir.
