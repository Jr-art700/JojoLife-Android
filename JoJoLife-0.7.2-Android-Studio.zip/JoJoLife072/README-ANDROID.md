# JoJoLife 0.7.2 — projeto Android

Este projeto empacota a versão web 0.7.2 do JoJoLife em um aplicativo Android usando WebView. O jogo é carregado localmente do próprio APK (não precisa de internet para abrir) e o armazenamento local do WebView fica ativado para permitir salvar/carregar o progresso.

## Como gerar o APK

1. Instale o **Android Studio** em um computador.
2. Extraia esta pasta `JoJoLife072`.
3. No Android Studio, escolha **Open** e selecione a pasta `JoJoLife072`.
4. Aguarde a sincronização do Gradle e instale o Android SDK 35 quando o Android Studio solicitar.
5. Para gerar um APK de teste: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Para distribuir publicamente, gere uma versão assinada em **Build → Generate Signed Bundle / APK**.

## Detalhes

- Nome: JoJoLife 0.7.2
- Application ID: `com.jojolife.app`
- Versão: `0.7.2` (versionCode 72)
- Android mínimo: 6.0 (API 23)
- Conteúdo do jogo: `app/src/main/assets/index.html`

**Importante:** este arquivo é o projeto-fonte Android pronto para compilar, não um APK já compilado. O ambiente em que este projeto foi preparado não tem Android SDK/Build Tools, então não foi possível gerar ou testar um APK instalável aqui.
